// Firestore && hooks
import { collection, doc, updateDoc } from "@firebase/firestore";
import { useCollectionData } from "react-firebase-hooks/firestore"
// React, bootstrap && router dom
import { useNavigate } from "react-router-dom";
import { Container, Card } from "react-bootstrap";
import { useState } from "react";
//imports from internal folders 
import { db, auth } from "../config/firebase";
import DeleteItem from "./deleteItem";
import CreateItem from "../modals/createItem";
import NavBar from "./navBar";



function ItemList({path, listName}) {
    const [nameSize, setNameSize] = useState(false);

    const navigate = useNavigate();
    
    //authentication api 
    const user = auth.currentUser;
    const userid = user.uid;

    //firestore connection to map through list items 
    const query = collection(db, path);
    const [docs, loading, error] = useCollectionData(query);
    // console.log("listname2", listName);

    //changes the with of name column size for longer name visability
    const nameSizing = () => {
        if(nameSize){
            setNameSize(false);
        }else{
            setNameSize(true);
        }
    }

    const backToHome =() => {
      navigate("/homepage");
    }


    //star (favourites)
    const editFavT = async (name) => {
        console.log(name);
            try{
              const itemDoc = doc(db, `users/${userid}/lists/${listName}/items`, name);
              await updateDoc(itemDoc, {favourite: false});
            }catch(err){
              console.error("Cannot update fav", err);
            }
        }
        const editFavF = async (name) => {
        
            try{
              const itemDoc = doc(db, `users/${userid}/lists/${listName}/items`, name);
              await updateDoc(itemDoc, {favourite: true});
            }catch(err){
              console.error("Cannot update fav", err);
            }
        }


return( 
    <div className="bg-light">
        <Container fluid className="pt-2 pb-3" style={{ minHeight: '92.4vh' }}>
            <div className="row w-100">
                <div className="col-auto pe-3 " style={{marginLeft: '11px'}}>
                    <CreateItem path={path}/>
                    <NavBar/>
                </div>

                <div className="col">
                    <Card 
                        className="text-dark p-3 rounded-4 mw-400"
                        style={{ minHeight: '80vh', maxHeight: '85vh', overflowY: 'auto', width: '100%' }}
                    >
                    {loading && "Loading..."}

                        <div className="d-flex align-items-center">
                            <i class="bi bi-arrow-left hoverable" onClick={backToHome}></i>
                            <h3 className="mb-0 ps-3 pb-1"> {listName}</h3>
                        </div>
                    {/**mapping through list items with click (for column sizing style), favourite and delete functionality  */}
                    {docs?.map((doc) => (
                        <div 
                            key={doc.name} 
                            className="d-grid align-items-center px-1 py-2 border-bottom hoverable2" 
                            onClick={nameSizing}
                            style={{ gridTemplateColumns: nameSize ? ('50rem 1fr auto') : ('20rem 1fr auto') , columnGap: '3rem', cursor: 'pointer' }}
                        >
                        <div className="d-flex align-items-center" style={{ flexShrink: 0, gap: '0.7rem', minWidth: 0 }}>

                            {doc.favourite ? (
                                    <i className="bi bi-star-fill text-warning " onClick={(e) => {
                                        e.stopPropagation();
                                        editFavT(doc.name)}} 
                                    ></i>
                                ) : (
                                    <i className="bi bi-star hoverable" onClick={(e) => {
                                        e.stopPropagation(); 
                                        editFavF(doc.name);
                                    }}></i> 
                                    )}

                            <h6 className="mb-0 text-truncate" style={{ maxWidth: '50rem' }}>{doc.name}</h6>
                        </div>
                        <p className="mb-0 text-muted text-truncate flex-grow-1">{doc.description}</p>    
                        <div className="ms-2">
                            <DeleteItem itemId={doc.name} path={path} />
                        </div>
                    </div>
                ))}
            </Card>
        </div>
    </div>
    </Container>
    </div>
    );
};



export default ItemList;