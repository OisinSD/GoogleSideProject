//Firestore
import { signOut } from "firebase/auth";
//imports from internal folders 
import { auth } from "../config/firebase";
import SearchBar from "./searchBar";
import S from "../assets/Google S.png";

function TopBar() {

    //authentication api
    const user = auth?.currentUser;
        // console.log("user api", user);
    const userimg = user?.photoURL;


    const logout = async () => { 
            try{
                await signOut(auth)
                
                } 
            catch(err){
                console.error("signout failed Google ", err);
            }
        };

    return(
        <div className="d-flex align-items-center gap-3 p-2 ms-3 bg-light">
            <div className="d-flex align-items-center gap-2">
                <img src={S} alt="Google list logo" className="img-fluid" style={{maxWidth: '40px'}}></img>
                <span className="fs-3 fw-semi text-dark">Glist</span>
                <div style={{ marginLeft: '4.3rem'}}>
                    <SearchBar/>
                </div>
            </div>
            {/**user.photoURL in top right with signout functionality onClick*/}
            <div className="ms-auto me-4 hoverable">
                <img src={userimg}  onClick={logout} alt="user" className="rounded-circle hoverable" style={{width: "40px", height: "40px", objectFit: "cover"}}></img>
            </div>
        </div>
    )
};

export default TopBar;