// Firestore && hooks
import { useCollectionData } from "react-firebase-hooks/firestore"
import { collection, doc, updateDoc} from 'firebase/firestore';
//Navigation react-router-dom
import { useNavigate } from "react-router-dom";
// React bootstrap
import {Card, Container} from "react-bootstrap";
// Imports from internal folders 
import { db, auth } from "../config/firebase"
import DeleteItem from './deleteItem';
import CreateList from "../modals/createList";
import TopBar from './topBar';
import "../App.css";
import NavBar from "./navBar";


function MainDisplay(){

    const navigate = useNavigate();

    //user authentication api
    const user = auth.currentUser;
    const userid = user.uid;

    //firestore db connection with particular path to map through lists
    const query = collection(db, `users/${userid}/lists`);
    const [lists, loading, error] = useCollectionData(query);

    // console.log("lists Test homepage:", lists);

    //onClick change route and pass(prop) through path && current listname
    const listItems = (path, listName) => {
        // console.log("listname2", listName);
        navigate("/listItemPage", {state: {path, listName}});
    }

    //star (favourite functionality)
 const editFavT = async (name) => {
        try{
          const itemDoc = doc(db, `users/${userid}/lists`, name);
          await updateDoc(itemDoc, {favourite: false});
        }catch(err){
          console.error("Cannot update fav", err);
        }
    }
        const editFavF = async (name) => {
    
        try{
          const itemDoc = doc(db, `users/${userid}/lists`, name);
          await updateDoc(itemDoc, {favourite: true});
        }catch(err){
          console.error("Cannot update fav", err);
        }
    }

    
    return(

        <div className="bg-light">
            {/**This is the main page display in a component */}
        <TopBar/>
            <Container fluid className="pt-2 pb-3" style={{ minHeight: '92.4vh' }}>
                <div className="row w-100">
                    <div className="col-auto pe-3 " style={{marginLeft: '11px'}}>
                        <CreateList path={`users/${userid}/lists`}/>
                        <NavBar/>
                    </div>
                    <div className="col">
                        <Card 
                            className="text-dark p-3 rounded-4 mw-400"
                            style={{ minHeight: '80vh', maxHeight: '85vh', overflowY: 'auto', width: '100%' }}
                        >
                        
                            {loading && "Loading..."}
                            
                            {/**mapping through lists on main page, with click, favourite and delete functionality */}
                            {lists?.map((list) => (
                                <div 
                                    key={list.name} 
                                    onClick={() => {listItems(`users/${userid}/lists/${list.name}/items`, list.name)}} 
                                    className="d-grid align-items-center px-1 py-2 border-bottom hoverable2" 
                                    style={{ gridTemplateColumns: '13rem 1fr auto', columnGap: '3rem', cursor: 'pointer' }}
                                >
                                <div className="d-flex align-items-center" style={{ flexShrink: 0, gap: '0.7rem', minWidth: 0 }}>

                                    {list.favourite ? (
                                    <i className="bi bi-star-fill text-warning " onClick={(e) => {
                                        e.stopPropagation();
                                        editFavT(list.name)}} 
                                    ></i>
                                ) : (
                                    <i className="bi bi-star hoverable" onClick={(e) => {
                                        e.stopPropagation(); 
                                        editFavF(list.name);
                                    }}></i> 
                                    )}

                                <h6 className="mb-0 text-truncate" style={{ maxWidth: '10rem' }}>{list.name}</h6>
                            </div>
                                <p className="mb-0 text-muted text-truncate flex-grow-1">{list.description}</p>
                            <div className="ms-2">
                               <DeleteItem itemId={list.name} path={`users/${userid}/lists`} />
                            </div>
                            </div>
                        ))}
                        </Card>
                    </div>
                </div>
            </Container>
        </div>
    );
};

export default MainDisplay;