//Firestore and hooks
import { useCollectionData } from "react-firebase-hooks/firestore";
import { collection } from "firebase/firestore";
//React bootstrap && router dom
import { useNavigate } from "react-router-dom";
import { Container, Card } from "react-bootstrap";
//imports from internal folders 
import { auth, db } from "../config/firebase";
import CreateList from "../modals/createList";
import DeleteItem from "../components/deleteItem";
import NavBar from "../components/navBar";
import TopBar from "../components/topBar";


function FavouriteList(){
  const navigate = useNavigate();

  //authentication api call
  const user = auth.currentUser;
  const userid = user.uid;
    
  //database list connection to map through lists (an only show if favourite is true)
  const query = collection(db, `users/${userid}/lists`);
  const [docs, loading, error] = useCollectionData(query);

  //onClick of list it shows items and passes through path with list name
  const listItems = (path, listName) => {
      navigate("/listItemPage", {state: {path, listName}});
  }

    return(
          <div className="bg-light">
            <TopBar/>
            <Container fluid className="pt-2 pb-3" style={{ minHeight: '92.4vh' }}>
              <div className="row w-100">
                <div className="col-auto pe-3 " style={{marginLeft: '11px'}}>
                  <CreateList path={`users/${userid}/lists`}/>
                  <NavBar/>
                </div>

    
                <div className="col">
                  <Card 
                    className="text-dark p-3 rounded-4 mw-400"
                    style={{ minHeight: '80vh', maxHeight: '85vh', overflowY: 'auto', width: '100%' }}
                  >
                    {loading && "Loading..."}
                    {/**mapping through list but showing only if favourite is true, with delete and opening items fucntionality */}
                    {docs?.map((doc) => 
                      doc.favourite && (
                      <div 
                        key={Math.random()} 
                          onClick={() => {listItems(`users/${userid}/lists/${doc.name}/items`, doc.name)}}
                          className="d-grid align-items-center px-1 py-2 border-bottom hoverable2" 
                          style={{ gridTemplateColumns: '13rem 1fr auto', columnGap: '3rem', cursor: 'pointer' }}
                        >
                        <div className="d-flex align-items-center " style={{ flexShrink: 0, gap: '0.7rem', minWidth: 0 }}>

                          {doc.favourite ? (
                              <i className="bi bi-star-fill text-warning " 
                                ></i>
                          ) : (
                            <i className="bi bi-star hoverable" 
                            ></i> 
                          )}

                            <h6 className="mb-0 text-truncate" style={{ maxWidth: '10rem' }}>{doc.name}</h6>
                          </div>
                            <p className="mb-0 text-muted text-truncate flex-grow-1">{doc.description}</p>
                          <div className="ms-2">
                            <DeleteItem itemId={doc.name} path={`shoppingList/${userid}/lists`} />
                        </div>
                      </div>
                      )
                    )}
                  </Card>
                </div>
              </div>
            </Container>
          </div>
    );
};

export default FavouriteList;