// React 
import { useState } from "react"

function SearchBar(){
    const [input, setInput] = useState("");

    return(
        <div className="d-flex justify-content-center">
            <div className="input-group bg-white rounded-5 shadow-sm" style={{height: "3.5rem", width: "35rem"}}> {/** the width style constricts resizing */}
                <span className="input-group-text bg-transparent border-0"> 
                    <i class="bi bi-search text-dark"></i>
                </span> 
                <input 
                    type="text"
                    className="form-control bg-transparent border-0 text-dark"
                    placeholder="Search lists"
                    autoComplete="off"
                // value={input}
                // onChange={(e) => handleChange(e.target.value)}
                // onKeyDown={handleChange}
                    style={{colorL: 'white'}}
                />
                {/**change to input true when i have functionality working  */}

                {!input && (
                    <span 
                    className="input-group-text bg-transparent border-0 text-dark"
                    role="button"
                    // onClick={clearInput}
                    >
                    <i class="bi bi-x-lg text dark"></i>
                    </span>
                )}
            </div>
        </div>
    );
};

export default SearchBar;
