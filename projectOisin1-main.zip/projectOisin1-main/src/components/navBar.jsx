import { Link, useLocation } from "react-router-dom";


function NavBar(){
    //used to check pathname for navbar styling
    const location = useLocation();

    return (
        <div class="container-fluid">
    <div class="row">
        <div class="col-sm-auto bg-light sticky-top">
            <div class="d-flex flex-sm-column flex-row flex-nowrap bg-light align-items-center sticky-top">
                
                <ul class="nav nav-pills nav-flush flex-sm-column flex-row flex-nowrap mb-auto mx-auto text-center align-items-center">
                    <li class="nav-item">
                        <Link to="/homepage" class="nav-link py-3 px-0 rounded-2" title="HomePage" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Home">
                            <i class={`bi bi-list-check hoverable text-dark rounded-2 ${location.pathname === '/homepage' ? 'bg-secondary text-white currentPage' : 'text-dark'}`}></i>
                        </Link>
                    </li>
                    <li>
                        <Link to="/favourite" class="py-3 px-0" title="Favourites" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Dashboard">
                            <i class={`bi bi-star hoverable text-dark rounded-2 ${location.pathname === '/favourite' ? 'bg-secondary text-white currentPage' : 'text-dark'}`}></i>
                        </Link>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
    );
};

export default NavBar;