//Firestore
import { doc, deleteDoc} from "firebase/firestore";
//imports from internal folders 
import { db } from "../config/firebase";

function DeleteItem({itemId, path}){

    //delete items onClick of trashcan
    const deleteItem = async (e) => {
        e.stopPropagation()
        try{
            const itemDoc = doc(db, path, itemId);
            await deleteDoc(itemDoc);
        }catch(err){
            console.error("Failed to delete item: ", err);
        }
    };

    return(
        <div>
             <i class="bi bi-trash hoverable" onClick={(e) => deleteItem(e)}></i>
        </div>
    );
};

export default DeleteItem;