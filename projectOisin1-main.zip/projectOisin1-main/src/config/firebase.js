
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

// import { getAnalytics } from "firebase/analytics";


const firebaseConfig = {
  apiKey: "AIzaSyBQgdGjVsuUqUOyaolNX-Wc56ck7H5eepA",
  authDomain: "projectoisin1.firebaseapp.com",
  projectId: "projectoisin1",
  storageBucket: "projectoisin1.firebasestorage.app",
  messagingSenderId: "1070369640662",
  appId: "1:1070369640662:web:7f7185bb880a2546163977",
  measurementId: "G-9XSQXKZQ2C"
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const provider = new GoogleAuthProvider();  
const db = getFirestore(app);
export {auth, provider, db};

// const analytics = getAnalytics(app);
