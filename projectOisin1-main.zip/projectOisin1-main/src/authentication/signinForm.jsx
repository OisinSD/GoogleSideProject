// bootstrap
import { Form, Container, Card } from "react-bootstrap";
//styling
import GoogleButton from "react-google-button";
import S from "../assets/Google S.png";
//firebase authentication
import { signInWithPopup} from "firebase/auth";
import { auth, provider } from "../config/firebase";

function SignInForm() {

    //using the signInWithPopup fucntionality on firebase
    const signinpop = async () => {
        try{
            await signInWithPopup(auth, provider);
            console.log("Popup Login successful");
        }catch(err){
            console.error("Failed to used popup", err);
        }
    }

    return(
      <Container 
      fluid
      className="d-flex justify-content-center align-items-center min-vh-100">
        <Card className="bg-light text-dark p-4 rounded-5 shadow-lg">
            <div className="d-flex flex-column align-content-center align-items-center">
                <img src={S} alt="Google Shopping list logo" className="img-fluid w-25"/>
                <h1 className="fw-bold text-center">Google Shopping List</h1>
            </div>
            <h2 className="fs-4 fw fw-semibold text-center">Lists made easy</h2>
            <p className="small text-secondary text-center">Sign up with your Google account to get Started</p>

            <Form className="d-flex flex-column align-items-center justify-content-center">
        <GoogleButton onClick={signinpop} /><br></br>
            </Form>
        </Card>
      </Container>
    
    );
};

export default SignInForm;