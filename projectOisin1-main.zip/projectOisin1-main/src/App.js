//react && router dom
import { useState } from "react";
import { BrowserRouter as Router,Routes,Route,Navigate } from "react-router-dom";
//pages
import HomePage from "./pages/homePage";
import SignIn from "./pages/Signin";
import ListItemsPage from "./pages/listItemPage";
import FavouritePage from "./pages/favouritePage";
//firebase && firestore
import { onAuthStateChanged } from "firebase/auth";
import { auth, db } from "./config/firebase";
import { doc, setDoc, getDoc } from "firebase/firestore";




function App() {
 const [signedIn, setSignedIn] = useState(false);
 
 // to check if user is signed in or not. 
 onAuthStateChanged(auth, async (user) => {
   if(user){
     setSignedIn(true);
     await createNewUserDoc(user);
     console.log("Logged in user info", user);
    }
    else{
      setSignedIn(false);
      // console.log("User signed out");
    };
  });
  

//creates user document in database if new user
  const createNewUserDoc = async (user) => {
    const decRef = doc(db, "users", user.uid);
    const docSnap = await getDoc(decRef);

    if(!docSnap.exists()){
      try{
        await setDoc(decRef, {email : user.email});
        console.log("User Document Created Successfully");
      }catch(err){
        console.error("Failed To Make User Document");
      }
    }else{
      console.log("User Already Has Document");
    }
  }



  return (
    <Router>
      <Routes>
        {signedIn ? (
          <>
            <Route path="/" element={<Navigate to="/homepage"/>}/>
            <Route path="/homepage" element={<HomePage/>}/>
            <Route path="/favourite" element={<FavouritePage/>}/>
            <Route path="/listItemPage" element={<ListItemsPage/>}/>
            <Route path="*" element={<Navigate to="/homepage"/>}/>
          </>
        ) : (
          <>
            <Route path="/signin" element={<SignIn/> }/>
            <Route path="*" element={<Navigate to="/signin" replace/>}/>
          </>
        )}
      </Routes>
    </Router>
  );
}

export default App;
