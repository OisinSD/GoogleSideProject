import ItemList from "../components/listOfItems";
import TopBar from "../components/topBar";
import { useLocation } from "react-router-dom";

function ListItemsPage() {

    //access data passed through useNavigate on mainDisplay, passed through to listofitems to be used there
    const location = useLocation();
    const path = location.state?.path;
    const listName = location.state?.listName;

    return(
        <div>
            <TopBar/>
            <ItemList path={path} listName={listName}/>
        </div>
    );
};
export default ListItemsPage;