import FavouriteList from "../components/favouriteList";

function FavouritePage(){
    return(
        <FavouriteList/>
    );
};

export default FavouritePage;