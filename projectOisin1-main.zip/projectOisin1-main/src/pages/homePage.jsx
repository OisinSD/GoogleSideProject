import MainDisplay from "../components/mainDisplay";

function HomePage(){
    return(
        <div>
            <MainDisplay/>
        </div>
    );
};

export default HomePage;