
import SignInForm from '../authentication/signinForm';

function SignIn(){
    return(
        <div>
            <SignInForm/>
        </div>
    )
}
export default SignIn;