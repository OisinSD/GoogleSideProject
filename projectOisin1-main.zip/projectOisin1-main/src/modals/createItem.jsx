//React & bootstrap
import { useState, useRef  } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
// Firestore
import { doc, setDoc } from "firebase/firestore";
//imports from internal folders 
import { db } from "../config/firebase";
import S from "../assets/Google S.png"


function CreateItem({path}) {
   // state to toggle modal 
  const [show, setShow] = useState(false);
  
  //inputs from modal
  const name = useRef();
  const description = useRef();
  const quantity = useRef();
  
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  
   //testing with regex
  const verificationName = /^[a-zA-Z0-9 ]+$/
  const verificationDes = /^[a-zA-Z0-9 ]*$/

  
  //creating new item
  const handleSubmit = async (nameTest, DesTest, e) => {
    e.preventDefault(); 
        //database call
    const decRef = doc(db, path, nameTest);
          await setDoc(decRef, {name: nameTest,
            description: DesTest,
            quantity: quantity.current.value
          });
        e.target.reset();
        handleClose();
      }
        
      //test conducted here wiht .test()
        const test = async (e) => {
          e.preventDefault();

          const nameTest = name.current.value;
          const DesTest = description.current.value;

          if (verificationName.test(nameTest) && verificationDes.test(DesTest)){
            await handleSubmit(nameTest, DesTest, e);
          }else{
            alert("Invalid input, Please insert alphabetic characters only")
        }
      }
          

  return (
    <>
    {/** button on show in listitempage(listofitems)*/}
      <Button  style={{backgroundColor: '#174EA6', borderColor: '#174EA6'}} onClick={handleShow} className="fw-bold ">
        <i class="bi bi-node-plus"></i>
      </Button>

    {/**This is the modal that opens when create list button clicked */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>
            <div className="d-flex align-items-center gap-2">
                <img src={S} alt="Google Lists Logo" className="img-fluid" style={{ maxWidth: '40px' }}></img>
                Create a new item
                </div>
                
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={test}>
            <Form.Group className="mb-3" controlId="listName">
              <Form.Label>List Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Banana..."
                ref={name}
                required
                autoFocus
                autoComplete='off'
              />
            </Form.Group>
            <Form.Group>
              <Form.Control 
              controlId="quantity"
              type="number"
              placeholder='Quantity'
              ref={quantity}
              required
              >
              </Form.Control>
              </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>Description</Form.Label>
              <Form.Control as="textarea" rows={3} ref={description} autoComplete='off' />
            </Form.Group>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button style={{backgroundColor: '#174EA6', borderColor: '#174EA6'}} className='ms-3' type="submit" onClick={handleClose}>
            Create Item
          </Button>
          </Form>
        </Modal.Body>
        <Modal.Footer>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default CreateItem;